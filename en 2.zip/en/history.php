<?php
    include 'config.php'; include 'cdn.php';
?>

<br>
        <h2 style="color: rgray; font-size: 27px; margin-left: 8%;"><a href="dashboard.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="white"><path d="m313-440 224 224-57 56-320-320 320-320 57 56-224 224h487v80H313Z"/></svg></a> Transaction History</h2> <hr>

        <div class="transaction_history">
            <h3></h3>
            <div class="search">
                <form action='<?php echo $_SERVER['PHP_SELF'];?>' method='get'>
                <br>
                <input type='search' name='query' placeholder='<?php if(isset($_GET['query'])) {echo 'TXN ID: '.$_GET['query'];} else {echo "Search Transaction ID";} ?>'/>
                <input type='hidden'  name='email' value='<?php echo $_GET["email"];?>'/>
                <input type='hidden' name='password'value='<?php echo $_GET["password"];?>'/>
               <button type='submit'>
               <svg xmlns="http://www.w3.org/2000/svg" height="30px" viewBox="0 -960 960 960" width="30px" fill="black"><path d="M96-216v-72h384v72H96Zm0-180v-72h192v72H96Zm0-180v-72h192v72H96Zm717 360L660-369q-23 16-50.5 24.5T552-336q-79.68 0-135.84-56.23-56.16-56.22-56.16-136Q360-608 416.23-664q56.22-56 136-56Q632-720 688-663.84q56 56.16 56 135.84 0 30-8.5 57.5T711-420l153 153-51 51ZM552-408q50 0 85-35t35-85q0-50-35-85t-85-35q-50 0-85 35t-35 85q0 50 35 85t85 35Z"/></svg>
                </button>
</form>
                <Br>
            </div>
            
          <?php
          
                $txn = $conn->query("select * from txns where uid = '{$_SESSION["uid"]}' ORDER BY txn_time DESC");
                if($txn->num_rows>0) {
                    //user available

                    if(isset($_GET["query"])) {
                            $new = $_GET["query"]/47229;
                            $specific_txn = $conn->query("select * from txns where uid = '{$_SESSION["uid"]}' and txn_id='$new'");
                            if($specific_txn->num_rows>0){
                                
                                while($prop = $specific_txn->fetch_assoc()) {
                                    ?>
                                                   <div class="txn_box">
                                                    
                                                    <div class="firstl" style="transform: scale(0.8);margin-left: -5%; background: #e6e6e6; padding: 7px 8px; border-radius: 100%; float:left; margin-top: -3%;">
                                                        <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="purple"><path d="M208-287.33V-540q0-14.17 9.62-23.75 9.61-9.58 23.83-9.58 14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.62 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm241.33 0V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm-336 166.66q-14.16 0-23.75-9.61Q80-139.9 80-154.12q0-14.21 9.58-23.71 9.59-9.5 23.75-9.5h733.34q14.16 0 23.75 9.61 9.58 9.62 9.58 23.84 0 14.21-9.58 23.71-9.59 9.5-23.75 9.5H113.33Zm572-166.66V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm164-352.67h-742q-11.39 0-19.36-7.97Q80-655.94 80-667.33V-686q0-7.67 4.17-14 4.16-6.33 10.5-10L448-903.33q15.11-8 32-8t32 8L864-711q7.67 4.33 11.83 11.67 4.17 7.33 4.17 16v11.82q0 13.39-8.82 22.45-8.81 9.06-21.85 9.06Zm-620.66-66.67h502.66-502.66Zm0 0h502.66L480-844.67l-251.33 138Z"/></svg>
                                                    </div>
                                                    <div class="secl">
                                                        <b style="color: purple;"><?php echo $prop['txn_type'];?></b>  <br>
                                                    <span>Transaction ID</span> <br>
                                                    <?php echo $prop['txn_id']*47229;?>
                                                    </div>
                                                    <div class="trl">
                                                        <b >
                                                        
                                                            <span id='pdf' style='font-size:12px;'></span>
                                                            <?php echo '$'.number_format($prop['txn_amt'], 2); ?>
                                                        
                                                        </b>  <br>
                                                        <span style="color: green;"><?php 
                                                        
                                                         switch($prop['txn_status']) {
                                                            case 'Confirmed': echo "<grr>Confirmed</grr>"; break;
                                                            case 'Pending': echo "<or>Pending</or>"; break;
                                                            case 'Failed': echo "<rd>Failed</rd>"; break;
                                                         }
                                                        
                                                        ?></span> <br>
                                                        <?php
                                                      $date = new DateTime($prop['txn_time']);
                                    echo $date->format('d M Y');
                                    echo "<br>";
                                    $date = new DateTime($prop['txn_time']);
                                    echo $date->format('h:i a');
                                    ?>
                                                    </div>
                                    
                                                </div><br>

                                    <?php
                                }
                            }
                            else {
                                echo '<h2>No such transaction ID!</h2>';
                            }
                            
              
                    }
                    else {
                    while($row = $txn->fetch_assoc()) {

                        ?>

        <div class="txn_box">
                <div class="firstl" style="transform: scale(0.8);margin-left: -5%; background: #e6e6e6; padding: 7px 8px; border-radius: 100%; float:left; margin-top: -3%;">
                    <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="purple"><path d="M208-287.33V-540q0-14.17 9.62-23.75 9.61-9.58 23.83-9.58 14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.62 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm241.33 0V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm-336 166.66q-14.16 0-23.75-9.61Q80-139.9 80-154.12q0-14.21 9.58-23.71 9.59-9.5 23.75-9.5h733.34q14.16 0 23.75 9.61 9.58 9.62 9.58 23.84 0 14.21-9.58 23.71-9.59 9.5-23.75 9.5H113.33Zm572-166.66V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm164-352.67h-742q-11.39 0-19.36-7.97Q80-655.94 80-667.33V-686q0-7.67 4.17-14 4.16-6.33 10.5-10L448-903.33q15.11-8 32-8t32 8L864-711q7.67 4.33 11.83 11.67 4.17 7.33 4.17 16v11.82q0 13.39-8.82 22.45-8.81 9.06-21.85 9.06Zm-620.66-66.67h502.66-502.66Zm0 0h502.66L480-844.67l-251.33 138Z"/></svg>
                </div>
                <div class="secl">
                    <b style="color: purple;"><?php echo $row['txn_type'];?></b>  <br>
                <span>Transaction ID</span> <br>
                <?php echo $row['txn_id']*47229;?>
                </div>
                <div class="trl">
                    <b >
                    
                        <span id='pdf' style='font-size:12px;'></span>
                        <?php echo '$'.number_format($row['txn_amt'], 2); ?>
                    
                    </b>  <br>
                    <span style="color: green;"><?php 
                    
                     switch($row['txn_status']) {
                        case 'Approved': echo "<grr>Confirmed</grr>"; break;
                        case 'Pending': echo "<or>Pending</or>"; break;
                        case 'Declined': echo "<rd>Failed</rd>"; break;
                     }
                    
                    ?></span> <br>
                    <?php
                  $date = new DateTime($row['txn_time']);
echo $date->format('d M Y');
echo "<br>";
$date = new DateTime($row['txn_time']);
echo $date->format('h:i a');
?>
                </div>

            </div><br>

            <?php
                    }
                }
                }
                else {
                   echo "<br><h4 style='text-align:center;'>No transactions yet</h4>";
                }

?>
<div class="footer">
          
<a href="dashboard.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M240-200h120v-200q0-17 11.5-28.5T400-440h160q17 0 28.5 11.5T600-400v200h120v-360L480-740 240-560v360Zm-80 0v-360q0-19 8.5-36t23.5-28l240-180q21-16 48-16t48 16l240 180q15 11 23.5 28t8.5 36v360q0 33-23.5 56.5T720-120H560q-17 0-28.5-11.5T520-160v-200h-80v200q0 17-11.5 28.5T400-120H240q-33 0-56.5-23.5T160-200Zm320-270Z"/></svg></div></a>

           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-156t86-127Q252-817 325-848.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 82-31.5 155T763-197.5q-54 54.5-127 86T480-80Zm0-60q142 0 241-99.5T820-480q0-142-99-241t-241-99q-141 0-240.5 99T140-480q0 141 99.5 240.5T480-140Zm0-340Zm-1 287q11 0 19-8.5t8-19.5v-24q60-7 94.5-40.5T635-371q0-52-28.5-83T508-508q-63-21-86.5-41.5T398-603q0-31 22.5-48.5T482-669q24 0 43 9t33 27q7 8 17 11t19-2q11-5 14.5-16t-3.5-20q-17-24-41.5-38T508-715v-24q0-11-8-19t-19-8q-11 0-19.5 8t-8.5 19v24q-51 7-80.5 37T343-603q0 49 25.5 78t94.5 55q71 27 94 47t23 52q0 33-27 55.5T487-293q-33 0-60.5-16T384-354q-5-8-13.5-12.5T353-368q-13 5-17.5 15.5T338-331q20 33 47.5 53.5T451-247v27q0 11 8.5 19t19.5 8Z"/></svg></div></a>

            
           <a href="history.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"><div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M110-200q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-260 110-260h340q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-470 110-470h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-680 110-680h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm450 300q-83 0-141.5-58.5T360-520q0-83 58.5-141.5T560-720q83 0 141.5 58.5T760-520q0 32-10 62t-30 56l139 139q9 9 9 21t-9 21q-9 9-21 9t-21-9L678-360q-26 20-56 30t-62 10Zm-.24-60Q618-380 659-420.76q41-40.77 41-99Q700-578 659.24-619q-40.77-41-99-41Q502-660 461-619.24q-41 40.77-41 99Q420-462 460.76-421q40.77 41 99 41Z"/></svg></div></a>


           
           <a href="profile.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M421-80q-14 0-25-9t-13-23l-15-94q-19-7-40-19t-37-25l-86 40q-14 6-28 1.5T155-226L97-330q-8-13-4.5-27t15.5-23l80-59q-2-9-2.5-20.5T185-480q0-9 .5-20.5T188-521l-80-59q-12-9-15.5-23t4.5-27l58-104q8-13 22-17.5t28 1.5l86 40q16-13 37-25t40-18l15-95q2-14 13-23t25-9h118q14 0 25 9t13 23l15 94q19 7 40.5 18.5T669-710l86-40q14-6 27.5-1.5T804-734l59 104q8 13 4.5 27.5T852-580l-80 57q2 10 2.5 21.5t.5 21.5q0 10-.5 21t-2.5 21l80 58q12 8 15.5 22.5T863-330l-58 104q-8 13-22 17.5t-28-1.5l-86-40q-16 13-36.5 25.5T592-206l-15 94q-2 14-13 23t-25 9H421Zm15-60h88l14-112q33-8 62.5-25t53.5-41l106 46 40-72-94-69q4-17 6.5-33.5T715-480q0-17-2-33.5t-7-33.5l94-69-40-72-106 46q-23-26-52-43.5T538-708l-14-112h-88l-14 112q-34 7-63.5 24T306-642l-106-46-40 72 94 69q-4 17-6.5 33.5T245-480q0 17 2.5 33.5T254-413l-94 69 40 72 106-46q24 24 53.5 41t62.5 25l14 112Zm44-210q54 0 92-38t38-92q0-54-38-92t-92-38q-54 0-92 38t-38 92q0 54 38 92t92 38Zm0-130Z"/></svg></div></a>
          
        
        </div>

<style>
    button {
        border:hidden;
        background:white;
        
        padding:2%;
        
        display:block;
        margin:auto;
        position: absolute;
        margin-top:-12%;
        margin-left:80%;
        float:right;
    }
    input{
        border:hidden;
        border:1px solid #e6e6e6;
        border-radius:7px;
        padding:3%;
        width:85%;
        display:block;
        margin:auto;
    }
       grr { color:green;} rd { color:red;} or { color:orange;}
            .txn_box { background: #e6e6e6; display: block;
            margin: auto;
            transform:scale(1.05);
                width: 87%;
                padding: 7%;
                padding-bottom: 14%;border-radius: 14px;
        }
            .firstl { float: left;}
            .secl { float: left; margin-top: -5%; font-size: 13px;}
            .trl { float: right; margin-top: -7%; font-size: 12px;}
            .boxes {
                
            }
            .bitcoin_assets {
                display: block;
                margin: auto;
                padding: 10%;
                border-radius: 10px;
                background: #d1d0d0;
                width: 90%;
            }
.footer {
               position: fixed;
               left: 0;
               bottom: 0;
               width: 100%;
               background-image: linear-gradient(165deg, black, black, #55555b );
               color: white;
               padding: 5%;
               text-align: center;
               border-top-right-radius: 7px;
               border-top-left-radius: 7px;
               column-count: 4;
            }
            .footer_next {
                column-count: 4;
            }
            body {
                font-family: 'SF Pro Display', sans-serif;
                                                
            }
            </style>