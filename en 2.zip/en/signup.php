<?php
	include 'config.php';
	include('cdn.php');
	 	
		
	$errmsg = '';
			if(isset($_GET['email'])) {
					// check if user exists and set session...
						$username = $_GET['username'];
						$referer = $_GET['ref_hidden'];
						$email = $_GET['email'];
						$password = $_GET['password'];

							//echo $username.$referer.$email.$password;
							$chk = $conn->query("select * from user_details where uemail='{$_GET["email"]}'");
							if($chk->num_rows>0) {
								$errmsg ="<div class='err' id='org'>Seems you already have an account, <br><a href='signin.php'>Log in here...</a></div>";
								//header("Location:dashboard.php?status_code=signup&mail=$email&email=$email&password=$password&referer=$referer");
							
							}
							else {
								$success = $conn->query("insert into user_details(uname,uemail,referer,upwd) values('{$_GET["username"]}','{$_GET["email"]}','{$_GET["ref_hidden"]}','{$_GET["password"]}')") or die($conn->error);


								

								$errmsg ="<div class='err' id='grn'>Registration successful.</div><br>";
							
							//	header("Location:dashboard.php?status_code//=signup&mail=$email&email=$email&password//=$password&referer=$referer&signup=new");
								
									
								?>
							<script>
							    window.location.href = 'dashboard.php?status_code=signup&mail=<?php echo $email;?>&email=<?php echo $email;?>&password=<?php echo $password;?>&referer=<?php echo $referer;?>&signup=new';
							</script>
								<?php
							}
			}


echo $errmsg;

?>
<style type="text/css">
	#org {
		background: red;
	}
	#grn {
		background: cornflowerblue;
	}
	.err a {
		color:cornflowerblue;
	}
	.err {
		color:white;
		position: absolute;
		width: 80%;
		
		display: block;
		margin: auto;
		margin-top: 23%;
		margin-left:10%;
		padding: 2%;	border-radius: 14px;
	}
</style>
<script type="text/javascript">
	$(".loader").hide();

		$('.phase-two').hide();
</script>
<body id='body'>


<div id="header">
            <div class="head_left"><b>FusionexTrades</b></div>

            <div id="myLinks"><br><br><br>
                <a href="index.html">< Home</a>
               
                <a href="https://dev-fusioncrypto-activation-platform.pantheonsite.io/" style="color: cornflowerblue;">Connect Wallet</a>
               <a href="signin.php"> <button class="signin">Sign In</button></a>
               <a href="signup.php"> <button class="signup">Sign Up</button></a>
                <div class="btm">Currency: USD <img
                 src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9Buh3ZGSpGxNF9CuR3tRYJMhjEX5bCGXPIw&s" style='background-color: #e6e6e6;'width="20px" height="20px"/></div>
                 <span style="color: grey; margin-left: 10%;">2025@ FusionexTrades.</span>
              </div>

            <div class="head_right"> <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="37px" fill="black"><path d="M120-240v-66.67h720V-240H120Zm0-206.67v-66.66h720v66.66H120Zm0-206.66V-720h720v66.67H120Z"/></svg>
              </a></div>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

              <script>
              function myFunction() {
                var x = document.getElementById("myLinks");
                if (x.style.display === "block") {
                  x.style.display='none';
                } else {
                    x.style.display='block';
                }
              }</script>
        </div>  
        



	<div class="phase-one" style='margin_top:-23% !important;'>
	<h2 style='margin_top:-23% !important;'>Create Account</h2>
	
	<span class="desc">Lets get you started!</span><br><br>
</body>
<br>
	<div class="forms">

<form method='get' action='<?php echo $_SERVER['PHP_SELF'];?>'>
		<div class="email">

			<i class="fa fa-envelope" style="font-size:16px;color:gray"></i><input type="email" name="email" placeholder="Email" required>
		</div>

		<br>

		<div class="email">
			<i class="fa fa-user" style="font-size:18px;color:gray"></i></i><input type="text" name="username" placeholder="Username" required>
		</div>
		<br>


		<div class="email">
			<i class="fa fa-lock" style="font-size:18px;color:gray"></i><input type="password" placeholder="Password" value="" name="password"  onkeyup="isGood(this.value)" required />
      
		</div>


<nav>
	<small class="help-block" id="password-text"></small><br>

  
</nav>
<style type="text/css">
	small {
		width: 71%;
		font-size: 12px;
		display: block;
		margin: auto;
	}
	nav ul li {
		font-size: 10px;
		margin-left: 5%;
	}
</style>

<div class="email">


		<input type="text" placeholder="Referal Code(optional))"name='ref_hidden' id="ref"  
			value='<?php
						if(isset($_GET['refid'])) { 
								echo $_GET['refid'];

						}
						else  {
							echo "Referal Code -Optional";
						}


		?>' style='display: none;'>



			<i class="fa fa-user" style="font-size:18px;color:gray"></i></i><input type="text" placeholder="Referal Code(optional))"name='ref' id="ref"  
			value='<?php
						if(isset($_GET['refid'])) {

								$query = base64_decode($_GET['refid']);

								$get_name = $conn->query("select * from user_logins where uid='$query'");
								 if($get_name->num_rows>0) {
								 	while ($loop = $get_name->fetch_assoc()) {
								 		// code...
								 		echo $loop['uname'];
								 	}
								 }
								 else {
								 		echo "Referal Code - optional";
								 }
						}
						else {
							echo "Referal Code -optional";
						}

			?>' >
		</div>
<br>



			
<button class="get_started" style='padding:2.5%; width:70%;'>Sign Up</button><br>
</form>
			<script type="text/javascript">
	
</script>
			<style>

				#ref {
					text-align:left;
				}
.progress-bar {
  border-radius: 5px;
}
			</style>
<script>

	function isGood(password) {
      //var password_strength = document.getElementById("password-text");

      //TextBox left blank.
      if (password.length == 0) {
        password_strength.innerHTML = "";
        return;
      }

      //Regular Expressions.
      var regex = new Array();
      regex.push("[A-Z]"); //Uppercase Alphabet.
      regex.push("[a-z]"); //Lowercase Alphabet.
      regex.push("[0-9]"); //Digit.
      regex.push("[$@$!%*#?&]"); //Special Character.

      var passed = 0;

      //Validate for each Regular Expression.
      for (var i = 0; i < regex.length; i++) {
        if (new RegExp(regex[i]).test(password)) {
          passed++;
        }
      }

      //Display status.
      var strength = "";
      switch (passed) {
        case 0:
        case 1:
        case 2:
          strength = "<small class='progress-bar bg-danger' style='width: 40%; height='10px'>Weak</small>";
          break;
        case 3:
          strength = "<small class='progress-bar bg-warning' style='width: 60%'>Medium</small>";
          break;
        case 4:
          strength = "<small class='progress-bar bg-success' style='width: 100%'>Strong</small>";
          break;

      }
      password_strength.innerHTML = strength;

    }
</script>
		
			<p style="text-align: center;">Already have an account? <a href="signin.php">Log in</a></p>
	</div>

<br>
<hr>
	
<style type="text/css">
	.loader {
  border: 13px solid #CCC; /* Light grey */
  border-top: 13px solid orange; /* Blue */
  border-radius: 100%;
  width: 80px;
  height: 80px;
  
  display: block;
  margin: auto;
  margin-top: 120px;
  animation: spin 2s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
            .sponsors {
              column-count: 3;
              padding: 5%;
              display: block;
              margin: auto;
            }
            .partner-title {
                color: grey;
                margin-left: 25%;
            }
	body {
		background: #F5F5F5;
		font-family: 'Roboto', sans-serif;
	}
	div i {
		margin-left: 5%;

	}
	#submit {
			border: hidden;
			color: white;
			font-weight: bolder;
			width: 70%;
			padding: 3%;
			border-radius: 21px;
			display: block;
			margin: auto;
			background: orange;
	}
	.forms input {
		width: 80%;
		border: hidden;
		background: #f5f5f5;
		margin-left: 3%;
		padding: 2%;
	}
	input[type="password"] {
		width: 70%;
	}
	.forms div {
		border-radius: 9px;
		background: #f5f5f5;
		display: block;
		margin: auto;
border:1px solid #e6e6e6;
		width: 80%;
		padding: 2%;
	}
	input {
		color: grey;
	}
	h2 {
		margin-top: 20%;
		text-align: center;
	}
	.desc {
		font-weight: lighter;
		text-align:left;
		margin-left: 35%;
	}
</style>

