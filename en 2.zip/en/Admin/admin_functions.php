<?php
include 'config.php';
                                      $sqlll = "SELECT count(txn_status) as tx FROM txn WHERE txn_type = 'Deposit' and txn_status='Pending'";
                                      $ress = $conn->query($sqlll);
                                      
                                      if ($ress->num_rows > 0) {
                                          while($roo = $ress->fetch_assoc()) {
                                              echo "".$roo["tx"];
                                             
                                          }
                                      } else {
                                          echo "$0";
                                      }
                              ?></span>