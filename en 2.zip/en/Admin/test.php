<?php
include 'config.php';
$sql = "SELECT * from user_details ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo $row["uid"];
       
    }
} else {
    echo "$0";
}
?>