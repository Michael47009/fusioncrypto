<?php
session_start();

$servername = "localhost";
$username = "ikkoqrkc_sudo";
$password = "LrZL_l[SxIV/eC/S";
$db = "ikkoqrkc_fusion";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " .$conn->connect_error);
}
function filter($input) {
	$input = trim($input);
	$input = stripslashes($input);
	$input = htmlspecialchars($input);
	return $input;
  }
//echo "Connected successfully";

?>