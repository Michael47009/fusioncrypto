<?php


    include 'config.php'; include 'cdn.php';
    if(isset($_GET['email']) or isset($_SESSION['uid'])) {
        $email = $_GET['email'];
        $pwd = $_GET['password'];
     
       // echo $email.$pwd;
        $get = $conn->query("select * from user_details where uemail='{$_GET["email"]}' and upwd='{$_GET["password"]}'");
             if($get->num_rows>0) {
                 while($list = $get->fetch_assoc()) {
                     $_SESSION['uid'] = $list['uid'];
                     $uid = $_SESSION['uid'];

                     if(isset($_GET['wallet'])) {
                            $conn->query("update user_details set wallet='{$_GET["wallet"]}' where uid='{$_SESSION["uid"]}'");
                            $conn->query("update user_details set location='{$_GET["location"]}' where uid='{$_SESSION["uid"]}'");

                           // header("Location:edit.php?status_code=new_deposit&email={$list["uemail"]}&password={$list["upwd"]}");
                            
                             ?>
                	<script>
							    window.location.href = 'edit.php?email=<?php echo $list["uemail"];?>&password=<?php echo $list["upwd"];?>';
							</script>
                
                <?php
            
                     }
                     //$uname = $list['u'];
     
                        // echo $_SESSION['uid'];
     
?>

<br>
        <h2 style="color: rgray; font-size: 27px; margin-left: 8%;"><a href="profile.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="black"><path d="m313-440 224 224-57 56-320-320 320-320 57 56-224 224h487v80H313Z"/></svg></a> Edit profile</h2> <hr>

        <?php
            if($list['p_img'] == null) {
                
                ?>
                         <img src='https://i.pinimg.com/736x/89/90/48/899048ab0cc455154006fdb9676964b3.jpg' width='25%' style='border-radius:100%; position:relative; display:block; margin:auto;  '/>

                <?php
            }
            else {
                
                ?>
                
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($list['p_img']); ?>" width='25%' style='border-radius:100%; position:relative; display:block; margin:auto; ' />


                <?php
            }
        ?>
        <a href="#?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">
        <div class="edit_btn">
        <svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="white"><path d="M240-192q-80 0-136-56.5T48-385q0-76 51.5-131.5T227-576q23.43-85.75 93.7-138.87Q390.98-768 480-768q107 0 185.5 68.5T744-528q70 0 119 49t49 118q0 70.42-49 119.71Q814-192 744-192H516q-29.7 0-50.85-21.15Q444-234.3 444-264v-174l-57 57-51-51 144-144 144 144-51 51-57-57v174h228q40.32 0 68.16-27.77 27.84-27.78 27.84-68Q840-400 812.16-428q-27.84-28-68.16-28h-72v-72q0-73-57.5-120.5t-135-47.5Q402-696 348-639.5T283-504h-43q-49.71 0-84.86 35.2-35.14 35.2-35.14 85t35.14 84.8q35.15 35 84.86 35h132v72H240Zm240-246Z"/></svg>
        </div></a>
        <form action='edit.php' method='get'>
        <br><br><br>
        <label>Full name</label>
        <input type="name" value="<?php echo $list["uname"];?>" name="name" disabled><br>
        <label>Email</label>
        <input type="email" value="<?php echo $list["uemail"];?>" name="em" disabled><br>
        <label>Bitcoin Wallet</label>
        <input type="text" value="<?php if($list["wallet"]==null) {echo '';} else { echo $list["wallet"];}?>"name="wallet" required><br>
        <label>Location</label>

        <input type="text" value="<?php if($list["location"]==null) {echo '';} else { echo $list["location"];}?>" name="location" required><br>
      
        <input type="hidden" value="<?php echo $list["uemail"];?>" name="email">
        <input type="hidden" value="<?php echo $list["upwd"];?>" name="password">
       <input type='submit' />
        </form>
        <p style='margin-left:5%; color:gray;'>Please use your correct details</p>
        <style>
             body {
                font-family: 'SF Pro Display', sans-serif;
                                                
            }
            label { margin-left:5%;}
            input {
			border: hidden;
			color: black;
            border:1px solid #ccc;
			border-radius:7px;
			width: 90%;
			padding: 2.5%;
			border-radius: 7px;
			display: block;
			margin: auto;
			background: white;
	}
    input[type='submit'] {
        border: hidden;
			color: white;
            border:1px solid #ccc;
			border-radius:7px;
			width: 90%;
			padding: 2.5%;
			border-radius: 7px;
			display: block;
			margin: auto;
			background: purple;
    }
            img {
                border:1px solid purple;
                padding:2%;
            }
            .edit_btn {
                    border-radius:100%;
                    padding:7px 0px 8px 2px;
                    text-align:center;
                    border:1px solid purple;
                    width:10%;
                    position: absolute;
                   background:purple;
                    margin-left:55%;
                    margin-top:-5%;
            }
            </style>
        <?php
            }
        }
        else {
            header("Location:signin.php");
                                
        }
        }
        //echo $_SESSION['uid'];
?>