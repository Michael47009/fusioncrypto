<?php
    include 'config.php';
    include 'cdn.php';
    
	if(isset($_GET['email']) or isset($_SESSION['uid'])) {
        $email = $_GET['email'];
        $pwd = $_GET['password'];
     
       // echo $email.$pwd;
        $get = $conn->query("select * from user_details where uemail='{$_GET["email"]}' and upwd='{$_GET["password"]}'");
             if($get->num_rows>0) {
                 while($list = $get->fetch_assoc()) {
                     $_SESSION['uid'] = $list['uid'];
                     $uid = $_SESSION['uid'];

                     if(isset($_GET['enable'])) {
                            if($_GET['enable'] =='dark') {
                        $conn->query("update user_details set darkmood='1' where uid='{$_SESSION["uid"]}'");
                        header("Location:profile.php?&email={$list["uemail"]}&password={$list["upwd"]}");
                    }
                    else {
                        $conn->query("update user_details set darkmood='0' where uid='{$_SESSION["uid"]}'");
                        header("Location:profile.php?&email={$list["uemail"]}&password={$list["upwd"]}");
                    }
                }
                     if($list['darkmood'] == '0') {
                            //off
                       
                        
                    }else {
                        //on
                        ?>
<style>
body {
    background:#121212;
    color:gray;
    font-weight:400;
}
hr {
    border-color: #ccc;
  border-style: solid;
  border-width: 1px 0 0 0;
}
#sv {
    fill:#404040;
}
.sec_tab {
    background:#262626 !important;
    color:gray !important;
}
.first_tab {
    background:#262626 !important;
    color:gray !important;
}
.leftt {
    color:gray !important;
}
.payment-process-panel {
    color:gray !important;
background:#121212 !important;

}
.sv {
fill:gray !important;
}
input {
    background:#121212 !important;
    border:hidden !important;
    border-bottom:1px solid #e6e6e6 !important;
}
select {
    background:#121212 !important;
    border:hidden !important;
    border:1px solid #e6e6e6 !important;
}
    </style>
                        <?php
                    }
     
                     


    if(isset($_GET['exact_amount'])) {
        $get_user = $conn->query("select * from user_details where uid ='{$_SESSION["uid"]}'");
        if($get_user->num_rows>0) {
            while($yes = $get_user->fetch_assoc()) {
                //echo $yes['uname'];
                $put = $conn->query("insert into txns(uid,username,txn_type,txn_status,txn_amt,plan) values('{$_SESSION["uid"]}','{$yes["uname"]}','Deposit','Pending','{$_GET["exact_amount"]}','{$_GET["select"]}')");

                //header("Location:history.php?status_code=new_deposit&email={$yes["uemail"]}&password=$password");
               // exit();
                
                ?>
                	<script>
							    window.location.href = 'history.php?status_code=new_deposit&mail=<?php echo $email;?>&email=<?php echo $yes["uemail"];?>&password=<?php echo $password;?>';
							</script>
                
                <?php
							

            }
        }
    }
       
      //  
    ?>


<style>
.footer {
               position: fixed;
               left: 0;
               bottom: 0;
               width: 100%;
               background-image: linear-gradient(165deg, black, black, #55555b );
               color: white;
               padding: 5%;
               text-align: center;
               border-top-right-radius: 7px;
               border-top-left-radius: 7px;
               column-count: 4;
            }
            .footer_next {
                column-count: 4;
            }
            body {
                font-family: 'SF Pro Display', sans-serif;
                                                
            }
            </style>
            <h3 style='text-align:center;'>Explore Investment Plans.</h3><br>
            <div class="payment-process-panel">
		<h2><a href="dashboard.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <svg class='sv' xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="black"><path d="m313-440 224 224-57 56-320-320 320-320 57 56-224 224h487v80H313Z"/></svg></a> Deposit BTC</h2>
        <span style='color:gray; margin-left:10%;'>Chain: BTC</span>
		<br>
			<div class="holdings">


				



					
			</div>





<div class="exp">
    <br>
<img src="btc.png" style='display: block; margin: auto; border-radius:12px;'width="80%">
</div><br>
			<h2 style='text-align:center; font-size:15px'>36cKJigarmib6vo5Gvvrird4ZPy7ukAZZNh 

          <svg class='sv' style='position:absolute; margin-top:-1%; margin-left:3%;' xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="black"><path d="M360-240q-29.7 0-50.85-21.15Q288-282.3 288-312v-480q0-29.7 21.15-50.85Q330.3-864 360-864h384q29.7 0 50.85 21.15Q816-821.7 816-792v480q0 29.7-21.15 50.85Q773.7-240 744-240H360Zm0-72h384v-480H360v480ZM216-96q-29.7 0-50.85-21.15Q144-138.3 144-168v-552h72v552h456v72H216Zm144-216v-480 480Z"/></svg></h2>


	<form method="get" action="deposit.php">
	<br>

	<select type='select' name="select"id="select" >

		<option>Investment Plan</option>
		<option>Starter Plan
$100 - $500</option>

		<option>Growth Plan
$501 - $1,000</option>

		<option>Premium Plan
$1,001 - $2,500</option>

		<option>Elite Plan
$2,501- $5,000</option>

		
	</select><br>

    <input type="number" placeholder="Enter Amount Sent." name="exact_amount">

<input type="text" value="<?php echo $_GET['email'];?>" name="email">

<input type="text" value="<?php echo $_GET['password'];?>" name="password"><br>
<button id="submit" onclick="dashboard();">Payment Made</button>

</form><br>
<div class="warn">
   - Please Only send Bitcoin to this address to prevent permanent loss of assets.<br>
   - Click "Payment Made" after the crypto has been sent
</div>
	</div>
	<br><br><br><br><</div>

<style type="text/css">
    .warn {
        color:gray;
        width:90%;
        margin-left:5%;
    }
    input[type='number'] {
			border: hidden;
			color: black;
            border:1px solid #ccc;
			font-weight: lighter;
			width: 90%;
			padding: 2.5%;
			border-radius: 1px;
			display: block;
			margin: auto;
			background: white;
	}
#select {
	width: 90%;
	border: hidden;
	background: white;
	border: 1px solid #ccd;
	padding: 2%;
	display: block;
	margin: auto;
}
input[type='text'] {
	display: none;
}
	#submit {
			border: hidden;
			color: white;
			font-weight: lighter;
			width: 90%;
			padding: 3%;
			border-radius: 7px;
			display: block;
			margin: auto;
			background: purple;
	}
	or {
		color: cornflowerblue;
        display:block;
        margin:auto;
		font-size: 13px;
	}
	.holdings {
		column-count: 3;
	}
	.card {
		margin-top: 3%;
		border: 1px solid #ccc;
		background: white;
	}
	.card img {
		margin-left: 5%;
	}
	red {
		color: red;
	}
	.payment-process-panel {
			background: #e6e6e6;
			color: black;
			display: block;
			margin: auto;

			border-radius: 14px;
			padding: 4%;
			width: 95%;

	}
	marquee {
		color: orange;
	}
	.phase-two {
		background: #262626;
		height: 100%;
		padding: 4%;
		color: white;
	}
</style>



<style type="text/css">
	.phase-two {
		background: #1a1a1a;
	}
</style>

<div class="footer">
          
<a href="dashboard.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M240-200h120v-200q0-17 11.5-28.5T400-440h160q17 0 28.5 11.5T600-400v200h120v-360L480-740 240-560v360Zm-80 0v-360q0-19 8.5-36t23.5-28l240-180q21-16 48-16t48 16l240 180q15 11 23.5 28t8.5 36v360q0 33-23.5 56.5T720-120H560q-17 0-28.5-11.5T520-160v-200h-80v200q0 17-11.5 28.5T400-120H240q-33 0-56.5-23.5T160-200Zm320-270Z"/></svg></div></a>

           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-156t86-127Q252-817 325-848.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 82-31.5 155T763-197.5q-54 54.5-127 86T480-80Zm0-60q142 0 241-99.5T820-480q0-142-99-241t-241-99q-141 0-240.5 99T140-480q0 141 99.5 240.5T480-140Zm0-340Zm-1 287q11 0 19-8.5t8-19.5v-24q60-7 94.5-40.5T635-371q0-52-28.5-83T508-508q-63-21-86.5-41.5T398-603q0-31 22.5-48.5T482-669q24 0 43 9t33 27q7 8 17 11t19-2q11-5 14.5-16t-3.5-20q-17-24-41.5-38T508-715v-24q0-11-8-19t-19-8q-11 0-19.5 8t-8.5 19v24q-51 7-80.5 37T343-603q0 49 25.5 78t94.5 55q71 27 94 47t23 52q0 33-27 55.5T487-293q-33 0-60.5-16T384-354q-5-8-13.5-12.5T353-368q-13 5-17.5 15.5T338-331q20 33 47.5 53.5T451-247v27q0 11 8.5 19t19.5 8Z"/></svg></div></a>

            
           <a href="history.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"><div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M110-200q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-260 110-260h340q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-470 110-470h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-680 110-680h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm450 300q-83 0-141.5-58.5T360-520q0-83 58.5-141.5T560-720q83 0 141.5 58.5T760-520q0 32-10 62t-30 56l139 139q9 9 9 21t-9 21q-9 9-21 9t-21-9L678-360q-26 20-56 30t-62 10Zm-.24-60Q618-380 659-420.76q41-40.77 41-99Q700-578 659.24-619q-40.77-41-99-41Q502-660 461-619.24q-41 40.77-41 99Q420-462 460.76-421q40.77 41 99 41Z"/></svg></div></a>


           
           <a href="profile.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M421-80q-14 0-25-9t-13-23l-15-94q-19-7-40-19t-37-25l-86 40q-14 6-28 1.5T155-226L97-330q-8-13-4.5-27t15.5-23l80-59q-2-9-2.5-20.5T185-480q0-9 .5-20.5T188-521l-80-59q-12-9-15.5-23t4.5-27l58-104q8-13 22-17.5t28 1.5l86 40q16-13 37-25t40-18l15-95q2-14 13-23t25-9h118q14 0 25 9t13 23l15 94q19 7 40.5 18.5T669-710l86-40q14-6 27.5-1.5T804-734l59 104q8 13 4.5 27.5T852-580l-80 57q2 10 2.5 21.5t.5 21.5q0 10-.5 21t-2.5 21l80 58q12 8 15.5 22.5T863-330l-58 104q-8 13-22 17.5t-28-1.5l-86-40q-16 13-36.5 25.5T592-206l-15 94q-2 14-13 23t-25 9H421Zm15-60h88l14-112q33-8 62.5-25t53.5-41l106 46 40-72-94-69q4-17 6.5-33.5T715-480q0-17-2-33.5t-7-33.5l94-69-40-72-106 46q-23-26-52-43.5T538-708l-14-112h-88l-14 112q-34 7-63.5 24T306-642l-106-46-40 72 94 69q-4 17-6.5 33.5T245-480q0 17 2.5 33.5T254-413l-94 69 40 72 106-46q24 24 53.5 41t62.5 25l14 112Zm44-210q54 0 92-38t38-92q0-54-38-92t-92-38q-54 0-92 38t-38 92q0 54 38 92t92 38Zm0-130Z"/></svg></div></a>
          
        
        </div>
		<?php
            }
        }
        else {
           ?>
           
           	<script>
							    window.location.href = 'signin.php';
							</script>
           <?php
                                
        }
        }
        //echo $_SESSION['uid'];
?>