<?php

include 'config.php';
include 'cdn.php';


if(isset($_GET['email']) or isset($_SESSION['uid'])) {
   $email = $_GET['email'];
   $pwd = $_GET['password'];

  // echo $email.$pwd;
   $get = $conn->query("select * from user_details where uemail='{$_GET["email"]}' and upwd='{$_GET["password"]}'");
        if($get->num_rows>0) {
            while($list = $get->fetch_assoc()) {
                $_SESSION['uid'] = $list['uid'];
                $uid = $_SESSION['uid'];
                //$uname = $list['u'];

                   // echo $_SESSION['uid'];

                    if(isset($_GET['signup'])) {
                           // echo 'set';
                          $chk = $conn->query("select * from user_balance where uid = '{$_SESSION["uid"]}' ");
                if($chk->num_rows>0) {
                    //do nothing
                }
                else {
                    $make_balance = $conn->query("
                    insert into user_balance(uid,username,balance) values('$uid','{$list["uname"]}','0.00')
                ");
                }
                      
                    }


                    if(isset($_GET['enable'])) {
                        if($_GET['enable'] =='dark') {
                    $conn->query("update user_details set darkmood='1' where uid='{$_SESSION["uid"]}'");
                  // header("Location:dashboard.php?&email={$list["uemail"]}&password={$list["upwd"]}");
                   
                   ?>
                	<script>
							    window.location.href = 'dashboard.php?email=<?php echo $list["uemail"];?>&password=<?php echo $list["upwd"];?>';
							</script>
                
                <?php
                }
                else {
                    $conn->query("update user_details set darkmood='0' where uid='{$_SESSION["uid"]}'");
                   // header("Location:dashboard.php?&email={$list["uemail"]}&password={$list["upwd"]}");
                    ?>
                	<script>
							    window.location.href = 'dashboard.php?email=<?php echo $list["uemail"];?>&password=<?php echo $list["upwd"];?>';
							</script>
                
                <?php
                }
            }
            if($list['darkmood'] == '1') {
                //off
                ?>
                <style>
                body {
                    background:#121212 !important;
                    color:white !important;
                    font-weight:400;
                }
                hr {
                    border-color: #404040;
                  border-style: solid;
                  border-width: 1px 0 0 0;
                }
                #sv {
                    fill:#404040;
                }

                .withdraw {

                    background-color: transparent !important;
                    border: 2px solid #2d2d2d !important ;
color: white !important;
}
                .deposit {

background-color: transparent !important;
border: 2px solid #2d2d2d !important ;
color: white !important;
}
                a { color:gray !important;}
              .larger_name { color:white !important;}
                .leftt {
                    color:gray !important;
                }
                .menus {
                    background:#262626 !important;
                    color:gray !important;
                }.menus-left {
                    background:#262626 !important;
                }
                .menus-left svg {
                    background:#262626 !important;
                }
                .menus-right {
                    background:#262626 !important;
                }
                .leftt {
                    background:#262626 !important;
                    color:gray !important;
                }.rightt {
                    background:#262626 !important;
                    color:gray !important;
                }.stock{
                    background:#262626 !important;
                    color:gray !important;
                } .normal{
                    background:#262626 !important;
                    color:gray !important;
                }
                #pf{
                    background:#262626 !important;
                    color:gray !important;
                }
                .bitcoin_assets {
                    background:#262626 !important;
                    color:gray !important;
                } .assets {
                    background:#262626 !important;
                    color:gray !important;
                } .txn_box{
                    background:#262626 !important;
                    color:gray !important;
                }
                .firstl {
                    background:#262626 !important;
                    color:gray !important;
                } 
                .secl {
                    background:#262626 !important;
                    color:gray !important;
                } 
                    </style>
                                        <?php
           
            
        }
                    ?>



  
    <body>
        <style>
            .head-content {
                column-count: 2;
                padding:4%;
                padding-top: 6%;
            } body { background: #e6e6e6;}
            .lf-content { color: gray; font-size:larger; margin-left: 5%; line-height: -56px;}
            .larger_name { color: black; font-size: 21px;}
            .larger_name_assets { color: white; font-size: 30px;}
            gr { color: gray;} .inc { color: green; margin-left: 10%;}
            .assets {padding: 6%; 
    background-image: linear-gradient(165deg, black, black, #55555b ); color: white; width: 90%; border-radius: 14px; display: block; margin: auto;} dy { margin-left: 30%;}
    .invn { margin-left: -14%; padding:7%; width: 125%; border: hidden; border-radius: 8px; color: white; font-size: 17px; background: rgb(79, 6, 79);}
            
    .Deposit { padding: 3%; width: 45%; border: hidden; border-radius: 11px; color: black; font-size: 17px; background: #FFF;}
    .withdraw { margin-left: 5%; padding: 3%; width: 45%; border: hidden; border-radius: 11px; color: white; font-size: 17px; background: #7a7979;}
            .badge { color: red; background: red; font-size: 15px; transform: scale(0.4); position: relative; margin-left: -9.3%; margin-top: -29.3%; } 
        </style>
        <div class="head-content">
            <div class="lf-content">
                <p>Welcome back!<br><span class="larger_name" style=''> <?php echo $list['uname'];?></span></p>
            </div>
          <div class="rg-content" style="text-align: right;">

         
          <a href="dashboard.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>&enable=<?php
            if($list['darkmood'] == '0') {
                //off
           echo 'dark';
            
        }
        else { 
            echo 'light';
        }
        ?>">    <svg id='sv' xmlns="http://www.w3.org/2000/svg" height="32px" style="margin-right: 4%;" viewBox="0 -960 960 960" width="32px" fill="gray"><path d="M480-120q-150 0-255-105T120-480q0-150 105-255t255-105q14 0 27.5 1t26.5 3q-41 29-65.5 75.5T444-660q0 90 63 153t153 63q55 0 101-24.5t75-65.5q2 13 3 26.5t1 27.5q0 150-105 255T480-120Zm0-80q88 0 158-48.5T740-375q-20 5-40 8t-40 3q-123 0-209.5-86.5T364-660q0-20 3-40t8-40q-78 32-126.5 102T200-480q0 116 82 198t198 82Zm-10-270Z"/></svg>
            </a>
<a id='myBtn' href='#'>
            <svg id='sv' xmlns="http://www.w3.org/2000/svg" id='myBtn' height="40px" viewBox="0 -960 960 960" width="35px" fill="gray"><path d="M160-200h640v-80H160v80Zm160-240h80v-120q0-33 23.5-56.5T480-640v-80q-66 0-113 47t-47 113v120Zm160 160Zm-200-80h400v-200q0-83-58.5-141.5T480-760q-83 0-141.5 58.5T280-560v200ZM160-120q-33 0-56.5-23.5T80-200v-80q0-33 23.5-56.5T160-360h40v-200q0-117 81.5-198.5T480-840q117 0 198.5 81.5T760-560v200h40q33 0 56.5 23.5T880-280v80q0 33-23.5 56.5T800-120H160Zm320-240Z"/></svg>
            <span class="badge" id='bd'> 1</span></a>

  <style>          .modal {
     font-family: 'SF Pro Display', sans-serif;
                    
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
.df {
    margin-left:-109%;
    
    padding:5%;
}
</style>

<body>


<!-- Trigger/Open The Modal -->

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span><br>
    <div class="df">
    <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="red"><path d="m40-120 440-760 440 760H40Zm115.33-66.67h649.34L480-746.67l-324.67 560ZM482.78-238q14.22 0 23.72-9.62 9.5-9.61 9.5-23.83 0-14.22-9.62-23.72-9.61-9.5-23.83-9.5-14.22 0-23.72 9.62-9.5 9.62-9.5 23.83 0 14.22 9.62 23.72 9.62 9.5 23.83 9.5Zm-33.45-114H516v-216h-66.67v216ZM480-466.67Z"/></svg>Login Notification!<br> <span id='inten' style='text-align:center;'>Some text in the Modal..</span><br><?php echo date('Y-m-d H:i:s');?>


    </div>
  </div>

</div>
<script>

</script>


<script>
// Get the modal
var modal = document.getElementById("myModal");
var btn = document.getElementById("myBtn");

var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
  const userAgent = navigator.userAgent;
const deviceName = userAgent.match(/(iphone|ipad|ipod|android|windows phone)/i);
if (deviceName) {
  document.getElementById('inten').innerHTML =`Device Name: ${deviceName[0].charAt(0).toUpperCase() + deviceName[0].slice(1)}`;
} else {
  console.log('Device Name: Unknown');
}

}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
  document.getElementById('bd').style.display='none';
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>




          </div>
        </div>

        <div class="portfolio_asset" style="width: 100%;">
        
            <div class="assets">
                <p> UID:  <?php echo $list['uid']*456;?><br><gr>Total asset value</gr><br><span class="larger_name_assets">
                    
               <?php

$asset = $conn->query("select * from user_balance where uid = '{$_SESSION["uid"]}' ");
                if($asset->num_rows>0) {
                    while($ast = $asset->fetch_assoc()) {
                        ?>

                       <span id='pp'></span>
                        <script>
                        let price =<?php  echo $ast['balance'];?>;

        
document.getElementById('pp').innerHTML = `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
</script>
                        <?php
                    }
                }
?>
            
            </span></p>
                <span class="growth"><svg xmlns="http://www.w3.org/2000/svg" height="24px"  style="position: absolute;" viewBox="0 -960 960 960" width="24px" fill="green"><path d="m136-240-56-56 296-298 160 160 208-206H640v-80h240v240h-80v-104L536-320 376-480 136-240Z"/></svg>
                    <span class="inc">
                        
                    <?php
                            $growth = $conn->query("select * from txns where uid = '{$_SESSION["uid"]}' and txn_type='deposit' and txn_status='approved'");
                            if($growth->num_rows>0) {
                                //creat %tage growth
                            }
                            else {
                                echo "<span style='color:orangered; opacity:0.8;'>0%</span>";
                            }

?>
                    </span> <gr>from last week.</gr>
                </span><br><br>

              
           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">  <button class="Deposit"><svg xmlns="http://www.w3.org/2000/svg" height="24px" style="position: absolute;" viewBox="0 -960 960 960" width="24px" fill="BLACK"><path d="M480-160q-100 0-170-70t-70-170h80q0 66 47 113t113 47q66 0 113-47t47-113h80q0 100-70 170t-170 70Zm0-201L320-521l56-57 64 64v-246h80v246l64-64 56 57-160 160Z"/></svg><dy>Deposit</dy></button></a>

               
           <a href="withdraw.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <button class="withdraw"><svg xmlns="http://www.w3.org/2000/svg" height="24px" style="position: absolute;" viewBox="0 -960 960 960" width="24px" fill="white"><path d="M280-160v-80h400v80H280Zm160-160v-327L336-544l-56-56 200-200 200 200-56 56-104-103v327h-80Z"/></svg><dy>Withdraw</dy></button></a>
          </div>
        
        </div><br>
        <p style="color: rgray; font-size: 17px; margin-left: 8%;">Assets Tradeable</p>
          
          
        <style>
            div.scrollmenu {
              
              overflow: auto;
              white-space: nowrap;
            }
            
            div.scrollmenu div {
              display: inline-block;
              color: black;
              background: #ccc;
            
              padding: 10px;
              text-decoration: none;
            }
            
            div.scrollmenu div:hover {
                transform: scale(1.01);
            }
            .menus-left {
                float: left;
            }
            .menus-right {
                float: right;
            }
            up {
                margin-top: -16%;
                color: green;
            }
            .stock { font-size: larger;}
            .menus  { border-radius: 14px; width: 89%;}
            .rightt { float: right; text-align: left;  margin-left: -12%; }
            .leftt {float: left; background: black; }
            </style>
        <div class="other_portfolios">
            <div class="scrollmenu">

                <div class="menus" style="margin-left: 5%;">

                    <div class="menus-left">
                        <div class="leftt">
                            <img src="https://cdn-icons-png.flaticon.com/512/0/747.png" width="40px">
                        </div>
                        <div class="rightt">
                            <span class="stock"><b>AAPL</b></span><br>
                            <span style="position: relative; margin-top: -65%; line-height: -40px; ">2M+ Investors</span>
                        </div>
                        <br><br><br><br><br>
                        <div class="normal">
                            <span class="stock" style="font-size: 17px; ">$79,242.54</span><br>
                            <span><svg xmlns="http://www.w3.org/2000/svg" height="24px"  style="position: relative;" viewBox="0 -960 960 960" width="24px" fill="green"><path d="m136-240-56-56 296-298 160 160 208-206H640v-80h240v240h-80v-104L536-320 376-480 136-240Z"/></svg> <up>73%</up><gr> from last week</gr></span>

                            </div>
                    </div>


                    <div class="menus-right">
                       
                        <span id='pf'style="position: relative; margin-top: -65%; ">Profits</span><br>
                        <span class="stock"><b>$16,239.3</b></span>
                            <br><br><br><br><br>
                           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">  <button class="invn"> Invest Now</button></a>
                    </div>
                </div>


                <div class="menus" style="margin-left: 2%;  width: 94%;">

                    <div class="menus-left">
                        <div class="leftt">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/e/e8/Tesla_logo.png" width="50px">
                        </div>
                        <div class="rightt">
                            <span class="stock"><b>TESLA INC.</b></span><br>
                            <span style="position: relative; margin-top: -65%; line-height: -40px; ">94K+ Investors</span>
                        </div>
                        <br><br><br><br><br>
                        <div class="normal">
                            <span class="stock" style="font-size: 17px; ">$22,292.57</span><br>
                            <span><svg xmlns="http://www.w3.org/2000/svg" height="24px"  style="position: relative;" viewBox="0 -960 960 960" width="24px" fill="green"><path d="m136-240-56-56 296-298 160 160 208-206H640v-80h240v240h-80v-104L536-320 376-480 136-240Z"/></svg> <up>19%</up></span>

                            </div>
                    </div>


                    <div class="menus-right">
                       
                        <span style="position: relative; margin-top: -65%; ">Profits</span><br>
                        <span class="stock"><b>$8,239.3</b></span>
                            <br><br><br><br><br>
                           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">  <button class="invn"> Invest Now</button></a>
                    </div>
                </div>

                



                <div class="menus" style="margin-left: 2%; width: 95%;">

                    <div class="menus-left">
                        <div class="leftt">
                            <img src="https://static.vecteezy.com/system/resources/previews/019/767/932/non_2x/bitcoin-logo-bitcoin-icon-transparent-free-png.png" width="60px">
                        </div>
                        <div class="rightt">
                            <span class="stock"><b>BTCOIN</b></span><br>
                            <span style="position: relative; margin-top: -65%; line-height: -40px; ">12M+ Investors</span>
                        </div>
                        <br><br><br><br><br>
                        <div class="normal">
                            <span class="stock" style="font-size: 17px; ">$502,292.57</span><br>
                            <span><svg xmlns="http://www.w3.org/2000/svg" height="24px"  style="position: relative;" viewBox="0 -960 960 960" width="24px" fill="green"><path d="m136-240-56-56 296-298 160 160 208-206H640v-80h240v240h-80v-104L536-320 376-480 136-240Z"/></svg> <up>359%</up></span>

                            </div>
                    </div>


                    <div class="menus-right">
                       
                        <span style="position: relative; margin-top: -65%; ">Profits</span><br>
                        <span class="stock"><b>$8,239.3</b></span>
                            <br><br><br><br><br>
                          <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">   <button class="invn"> Invest Now</button></a>
                    </div>
                </div>

                



              </div>
        </div>
<br>
        <p style="color: rgray; font-size: 17px; margin-left: 8%;">Asset value</p>
        <div class="bitcoin_assets">
            <div class="boxes" style="transform: rotate(20deg);margin-left: -5%; background: #e6e6e6; padding: 7px 8px; border-radius: 100%; float:left; margin-top: -9%;">
                <svg xmlns="http://www.w3.org/2000/svg" height="35px" viewBox="0 -960 960 960" width="35px" fill="black"><path d="M370-150v-60H270q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32 8.62-8.5 21.37-8.5h60v-420h-60q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32 8.62-8.5 21.37-8.5h100v-60q0-12.75 8.68-21.38 8.67-8.62 21.5-8.62 12.82 0 21.32 8.62 8.5 8.63 8.5 21.38v60h110v-60q0-12.75 8.68-21.38 8.67-8.62 21.5-8.62 12.82 0 21.32 8.62 8.5 8.63 8.5 21.38v63q54 11 87 53t33 94q0 28-11 55.5T677-495q39 20 61 56.5t22 78.1q0 62.4-43.5 106.4Q673-210 610-210h-10v60q0 12.75-8.68 21.37-8.67 8.63-21.5 8.63-12.82 0-21.32-8.63-8.5-8.62-8.5-21.37v-60H430v60q0 12.75-8.68 21.37-8.67 8.63-21.5 8.63-12.82 0-21.32-8.63-8.5-8.62-8.5-21.37Zm20-360h180q38 0 64-26.44T660-600q0-38-26-64t-64-26H390v180Zm0 240h220q38 0 64-26.44T700-360q0-38-26-64t-64-26H390v180Z"/></svg> 
                   
            </div>
            <div class="boxes" style="float: left;margin-left: 5%; margin-top: -7%;">
                <b>BITCOIN</b>  <br>
                BTC  

            </div>

            <div class="boxes" style="float: left;margin-left: 5%; margin-top: -7%;">
                <svg id="svg" xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M360.5-80q-10.5 0-18.48-5.63Q334.04-91.25 331-101L228-450H110q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-510 110-510h140q9.92 0 17.93 5.62 8.02 5.63 11.07 15.38l76 256 136-623q2-11 10.25-17.5T520-880q10.5 0 18.75 6T549-857l94 423 68-225q3.06-9.75 11.09-15.38 8.03-5.62 17.97-5.62t17.44 5q7.5 5 10.5 14l54 151h28q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5h-50q-9.85 0-17.42-5.5Q775-461 772-470l-30-83-74 252q-2.89 9.63-10.83 15.81-7.95 6.19-18.06 5.19T621-287q-8-6-10-16l-91-402-131 602q-2.25 10.39-10.12 16.32Q371-80.74 360.5-80Z"/></svg>

            </div>

            <div class="boxes" style="float: right; margin-top: -7%; margin-left: -90%;">
                <b id="live_btc_price"><i>loading...</i></b>  <br>


                <?php

$dev = $conn->query("select * from user_balance where uid = '{$_SESSION["uid"]}' ");
                if($dev->num_rows>0) {
                    
                    while($astt = $dev->fetch_assoc()) {
                        
                        
                         ?>

                       <span id='pd' style='font-size:12px;'></span>
                        <script>
                        let pric =<?php  echo $astt['balance'];?>;

        
document.getElementById('pd').innerHTML = `$${pric.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` +"";
</script>
                        <?php
                    }
                }
?>
                 
            </div>
<script>
  
  let ws = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@trade');
  let lastPrice = null;
    let elm = document.getElementById('live_btc_price');
    let svg = document.getElementById('svg');

    ws.onmessage=(event) => {
        let stockObject = JSON.parse(event.data);
        let price = parseFloat(stockObject.p);
//console.log(price/);
        
       elm.innerHTML = `$${price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
       svg.style.fill = !lastPrice || lastPrice === price ? 'gray' : price > lastPrice ? 'green': 'red';

        document.getElementById('live_btc_price').style.color = !lastPrice || lastPrice === price ? 'black' : price > lastPrice ? 'green': 'red';
        lastPrice = price;
    }

  
</script>
            

        </div>

        <br>
        <p style="color: rgray; font-size: 17px; margin-left: 8%;">Transaction History</p>

        <div class="transaction_history">
          <?php
          
                $txn = $conn->query("select * from txns where uid = '{$_SESSION["uid"]}' ORDER BY txn_time DESC limit 3");
                if($txn->num_rows>0) {
                    //user available
                    while($row = $txn->fetch_assoc()) {
                        ?>

        <div class="txn_box">
                <div class="firstl" style="transform: scale(0.8);margin-left: -5%; background: #e6e6e6; padding: 7px 8px; border-radius: 100%; float:left; margin-top: -3%;">
                    <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="purple"><path d="M208-287.33V-540q0-14.17 9.62-23.75 9.61-9.58 23.83-9.58 14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.62 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm241.33 0V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm-336 166.66q-14.16 0-23.75-9.61Q80-139.9 80-154.12q0-14.21 9.58-23.71 9.59-9.5 23.75-9.5h733.34q14.16 0 23.75 9.61 9.58 9.62 9.58 23.84 0 14.21-9.58 23.71-9.59 9.5-23.75 9.5H113.33Zm572-166.66V-540q0-14.17 9.62-23.75t23.83-9.58q14.22 0 23.72 9.58 9.5 9.58 9.5 23.75v252.67q0 14.16-9.62 23.75-9.61 9.58-23.83 9.58-14.22 0-23.72-9.58-9.5-9.59-9.5-23.75Zm164-352.67h-742q-11.39 0-19.36-7.97Q80-655.94 80-667.33V-686q0-7.67 4.17-14 4.16-6.33 10.5-10L448-903.33q15.11-8 32-8t32 8L864-711q7.67 4.33 11.83 11.67 4.17 7.33 4.17 16v11.82q0 13.39-8.82 22.45-8.81 9.06-21.85 9.06Zm-620.66-66.67h502.66-502.66Zm0 0h502.66L480-844.67l-251.33 138Z"/></svg>
                </div>
                <div class="secl">
                    <b style="color: purple;"><?php echo $row['txn_type'];?></b>  <br>
                <span>Transaction ID</span> <br>
                <?php echo $row['txn_id']*47229;?>
                </div>
                <div class="trl">
                    <b >
                    
                        <span id='pdf' style='font-size:12px;'></span>
                        <?php echo '$'.number_format($row['txn_amt'], 2); ?>
                    
                    </b>  <br>
                    <span style="color: green;"><?php 
                    
                     switch($row['txn_status']) {
                        case 'Approved': echo "<grr>Confirmed</grr>"; break;
                        case 'Pending': echo "<or>Pending</or>"; break;
                        case 'Declined': echo "<rd>Failed</rd>"; break;
                     }
                    
                    ?></span> <br>
                    <?php
                  $date = new DateTime($row['txn_time']);
echo $date->format('d M Y');
echo "<br>";
$date = new DateTime($row['txn_time']);
echo $date->format('h:i a');
?>
                </div>
             
            </div><br>
<?php
                    }
                    ?>

                    <h4 style='text-align:center;'>Check full
                    <a href="history.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>">Transaction History..</a></h4>
             <?php   }
                else {
                   echo "<br><h4 style='text-align:center;'>No transactions yet</h4>";
                }

?>
     </div><br>
           
            <br><br><br>
        <style>
            grr { color:green;} rd { color:red;} or { color:orange;}
            .txn_box { background: #cac8c8; display: block;
            margin: auto;
            transform:scale(1.05);
                width: 87%;
                padding: 7%;
                padding-bottom: 14%;border-radius: 14px;
        }
            .firstl { float: left;}
            .secl { float: left; margin-top: -5%; font-size: 13px;}
            .trl { float: right; margin-top: -7%; font-size: 12px;}
            .boxes {
                
            }
            .bitcoin_assets {
                display: block;
                margin: auto;
                padding: 10%;
                border-radius: 10px;
                background: #d1d0d0;
                width: 90%;
            }
            .footer {
               position: fixed;
               left: 0;
               bottom: 0;
               width: 100%;
               background-image: linear-gradient(165deg, black, black, #55555b );
               color: white;
               padding: 5%;
               text-align: center;
               border-top-right-radius: 7px;
               border-top-left-radius: 7px;
               column-count: 4;
            }
            .footer_next {
                column-count: 4;
            }
            body {
                font-family: 'SF Pro Display', sans-serif;
                                                
            }
            </style>

        <div class="footer">
           <a href='#'> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M240-200h120v-200q0-17 11.5-28.5T400-440h160q17 0 28.5 11.5T600-400v200h120v-360L480-740 240-560v360Zm-80 0v-360q0-19 8.5-36t23.5-28l240-180q21-16 48-16t48 16l240 180q15 11 23.5 28t8.5 36v360q0 33-23.5 56.5T720-120H560q-17 0-28.5-11.5T520-160v-200h-80v200q0 17-11.5 28.5T400-120H240q-33 0-56.5-23.5T160-200Zm320-270Z"/></svg></div></a>

           <a href="deposit.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M480-80q-82 0-155-31.5t-127.5-86Q143-252 111.5-325T80-480q0-83 31.5-156t86-127Q252-817 325-848.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 82-31.5 155T763-197.5q-54 54.5-127 86T480-80Zm0-60q142 0 241-99.5T820-480q0-142-99-241t-241-99q-141 0-240.5 99T140-480q0 141 99.5 240.5T480-140Zm0-340Zm-1 287q11 0 19-8.5t8-19.5v-24q60-7 94.5-40.5T635-371q0-52-28.5-83T508-508q-63-21-86.5-41.5T398-603q0-31 22.5-48.5T482-669q24 0 43 9t33 27q7 8 17 11t19-2q11-5 14.5-16t-3.5-20q-17-24-41.5-38T508-715v-24q0-11-8-19t-19-8q-11 0-19.5 8t-8.5 19v24q-51 7-80.5 37T343-603q0 49 25.5 78t94.5 55q71 27 94 47t23 52q0 33-27 55.5T487-293q-33 0-60.5-16T384-354q-5-8-13.5-12.5T353-368q-13 5-17.5 15.5T338-331q20 33 47.5 53.5T451-247v27q0 11 8.5 19t19.5 8Z"/></svg></div></a>

            
           <a href="history.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"><div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M110-200q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-260 110-260h340q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-470 110-470h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm0-210q-12.75 0-21.37-8.68-8.63-8.67-8.63-21.5 0-12.82 8.63-21.32Q97.25-680 110-680h140q12.75 0 21.38 8.68 8.62 8.67 8.62 21.5 0 12.82-8.62 21.32-8.63 8.5-21.38 8.5H110Zm450 300q-83 0-141.5-58.5T360-520q0-83 58.5-141.5T560-720q83 0 141.5 58.5T760-520q0 32-10 62t-30 56l139 139q9 9 9 21t-9 21q-9 9-21 9t-21-9L678-360q-26 20-56 30t-62 10Zm-.24-60Q618-380 659-420.76q41-40.77 41-99Q700-578 659.24-619q-40.77-41-99-41Q502-660 461-619.24q-41 40.77-41 99Q420-462 460.76-421q40.77 41 99 41Z"/></svg></div></a>


           
           <a href="profile.php?email=<?php echo $_GET["email"];?>&password=<?php echo $_GET["password"]?>"> <div class="icons"><svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="40px" fill="gray"><path d="M421-80q-14 0-25-9t-13-23l-15-94q-19-7-40-19t-37-25l-86 40q-14 6-28 1.5T155-226L97-330q-8-13-4.5-27t15.5-23l80-59q-2-9-2.5-20.5T185-480q0-9 .5-20.5T188-521l-80-59q-12-9-15.5-23t4.5-27l58-104q8-13 22-17.5t28 1.5l86 40q16-13 37-25t40-18l15-95q2-14 13-23t25-9h118q14 0 25 9t13 23l15 94q19 7 40.5 18.5T669-710l86-40q14-6 27.5-1.5T804-734l59 104q8 13 4.5 27.5T852-580l-80 57q2 10 2.5 21.5t.5 21.5q0 10-.5 21t-2.5 21l80 58q12 8 15.5 22.5T863-330l-58 104q-8 13-22 17.5t-28-1.5l-86-40q-16 13-36.5 25.5T592-206l-15 94q-2 14-13 23t-25 9H421Zm15-60h88l14-112q33-8 62.5-25t53.5-41l106 46 40-72-94-69q4-17 6.5-33.5T715-480q0-17-2-33.5t-7-33.5l94-69-40-72-106 46q-23-26-52-43.5T538-708l-14-112h-88l-14 112q-34 7-63.5 24T306-642l-106-46-40 72 94 69q-4 17-6.5 33.5T245-480q0 17 2.5 33.5T254-413l-94 69 40 72 106-46q24 24 53.5 41t62.5 25l14 112Zm44-210q54 0 92-38t38-92q0-54-38-92t-92-38q-54 0-92 38t-38 92q0 54 38 92t92 38Zm0-130Z"/></svg></div></a>
          
        
        </div>
          
         
    </body>  

    <?php
            }
        }
        else {
            //header("Location:signin.php");
            ?>
            	<script>
							    window.location.href = 'signin.php';
							</script><?php
                                
        }
        }
        //echo $_SESSION['uid'];
?>
ß