<?php
include 'config.php';
	include('cdn.php');


	if (isset($_GET['incorrect'])) {
		// code...

		echo "<br><div class='err' id='org'>incorrect username or password!</div>";
	}
	$errmsg = '';
			if(isset($_GET['email'])) {
					// check if user exists and set session...
						$email = filter($_GET['email']);
						$password = filter($_GET['password']);

							//echo $email.$password;
							$chk = $conn->query("select * from user_details where uemail='$email' and upwd='$password'");

							if($chk->num_rows>0) {
								while($rr = $chk->fetch_assoc()) {
									$_SESSION['uid'] = $rr['uid'];
									
							//	header("Location:dashboard.php?status_code=signin&email=$email&password=$password");?>
								
								
									<script>
							    window.location.href = 'dashboard.php?status_code=sigin&mail=<?php echo $email;?>&email=<?php echo $email;?>&password=<?php echo $password;?>';
							</script>
								<?php
							
								}
								
							}
							else {
								$errmsg ="<div class='err' id='org'>Incorrect Email and Password combination.</div><br>";
								
							}
							
			}


echo $errmsg;
?>
<style type="text/css">
	#org {
		background: red;
	}
	
	.err {
		color:white;
		position: absolute;
		width: 80%;
		
		display: block;
		margin: auto;
		margin-top: 23%;
		margin-left:10%;
		padding: 3%;	border-radius: 14px;
	}
</style>
<body>


<div id="header">
            <div class="head_left"><b>FusionexTrades</b></div>

            <div id="myLinks"><br><br><br>
                <a href="index.html">< Home</a>
               
                <a href="#about" style="color: cornflowerblue;">Connect Wallet</a>
               <a href="signin.php"> <button class="signin">Sign In</button></a>
               <a href="signup.php"> <button class="signup">Sign Up</button></a>
                <div class="btm">Currency: USD <img
                 src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9Buh3ZGSpGxNF9CuR3tRYJMhjEX5bCGXPIw&s" style='background-color: #e6e6e6;'width="20px" height="20px"/></div>
                 <span style="color: grey; margin-left: 10%;">2025@ FusionCryptoInvestment.</span>
              </div>

            <div class="head_right"> <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <svg xmlns="http://www.w3.org/2000/svg" height="40px" viewBox="0 -960 960 960" width="37px" fill="black"><path d="M120-240v-66.67h720V-240H120Zm0-206.67v-66.66h720v66.66H120Zm0-206.66V-720h720v66.67H120Z"/></svg>
              </a></div>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

              <script>
              function myFunction() {
                var x = document.getElementById("myLinks");
                if (x.style.display === "block") {
                  x.style.display='none';
                } else {
                    x.style.display='block';
                }
              }</script>
        </div>  
        



	<h2>Welcome back.</h2>
	<span class="desc">Lets get you loggedin!</span>
</body>
<br><br><br><br>
	<div class="forms">
		<form method="get" action="signin.php">

		<div class="email" style='border:1px solid #e6e6e6;'>

			<i class="fa fa-envelope" style="font-size:16px;color:gray"></i><input type="email" name="email" placeholder="Email" required>
		</div>

		<br>

		

		<div class="email" style='border:1px solid #e6e6e6;'>
			<i class="fa fa-lock" style="font-size:18px;color:gray"></i></i><input type="text" type="password" placeholder="Password" name="password" required>
		</div>

<br><br>

			
			
<button class="get_started" style='padding:2.5%; width:70%;'>Sign In</button><br>

		</form>
			<p style="text-align: center;">Dont have an account? <a href="signup.php">Register here..</a></p>
	</div>

<br>
<hr>
	


	</div>
<style type="text/css">
            .sponsors {
              column-count: 3;
              padding: 5%;
              display: block;
              margin: auto;
            }
            .partner-title {
                color: grey;
                margin-left: 25%;
            }
	body {
		background: #F5F5F5;
		font-family: 'Roboto', sans-serif;
	}
	div i {
		margin-left: 5%;

	}
	.forms input[type='submit'] {
			border: hidden;
			color: white;
			font-weight: bolder;
			width: 70%;
			padding: 3%;
			border-radius: 21px;
			display: block;
			margin: auto;
			background: orange;
	}
	.forms input {
		width: 80%;
		border: hidden;
		background: #f5f5f5;
		margin-left: 3%;
		padding: 2%;
		
	}
	.forms div {
		border-radius: 9px;
		background: #f5f5f5;
		display: block;
		margin: auto;
		width: 80%;
		padding: 3%;
	}
	input {
		color: grey;
	}
	h2 {
		margin-top: 20%;
		text-align: center;
	}
	.desc {
		font-weight: lighter;
		display: block;
		margin-left: 35%;
	}
</style>

